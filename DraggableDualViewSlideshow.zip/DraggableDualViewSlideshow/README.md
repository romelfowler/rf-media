Draggable Dual-View Slideshow
=========

A draggable slideshow with two views: fullscreen and small carousel. In fullscreen view, a related content area can be viewed.

[Article on Codrops](http://tympanus.net/codrops/?p=19332)

[Demo](http://tympanus.net/Development/DraggableDualViewSlideshow/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[Dragdealer.js 0.9.7](http://github.com/skidding/dragdealer) by Ovidiu Cherecheș

Images by [Unsplash](http://unsplash.com)

[© Codrops 2014](http://www.codrops.com)